$(function () { // wait for document ready
		
	var controller = new ScrollMagic.Controller();
	
	var tween = TweenMax.to(".product__visual", 1, {scale: 5, ease: Linear.easeNone});
	
	// build scene
	var scene = new ScrollMagic.Scene({triggerElement: "#product", triggerHook: 'onLeave', duration: 1000})
		.setTween(tween)
		.setPin("#product")
		.addIndicators({name: "INTRO"}) // add indicators (requires plugin)
		.addTo(controller);
});