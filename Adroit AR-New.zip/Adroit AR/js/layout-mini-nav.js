// (function($) {
//     "use strict"

//     new dezSettings({
//         sidebarStyle: "mini",
//         headerPosition: "fixed",
//         sidebarPosition: "fixed"        
//     });


// })(jQuery);

(function($) {
	
    var direction =  getUrlParams('dir');
    if(direction != 'rtl')
    {direction = 'ltr'; }
        
    new dezSettings({
        typography: "roboto",
        version: "light",
        layout: "Vertical",
        headerBg: "color_1",
        navheaderBg: "color_1",
        sidebarBg: "color_2",
        sidebarStyle: "full",
        sidebarPosition: "fixed",
        headerPosition: "fixed",
        containerLayout: "full",
        direction: direction
    }); 
    
    })(jQuery);